<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        // get form data
        $name = htmlspecialchars($_POST['name']);
        $email = htmlspecialchars($_POST['email']);
        $subject = htmlspecialchars($_POST['subject']);
        $message = htmlspecialchars($_POST['message']);


        //set reciepient email
        $to ="masendiaaron6@gmail.com";
        $subject = "New contact form submission from $name";

        // build email body
        $body ="
        name: $name\n
        Email: $email\n
        Subject: $subject\n\n
        Message: \n$message
        ";

        //Set headers
        if (mail($to, $subject, $body,$headers)){
            echo "<p> Thank you! Your message has been sent.</p>";
        } else {
            echo "<p>Oops! Something went wromg. Please try again.</p>"
        }

    }
?>
